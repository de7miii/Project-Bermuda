package com.example.freelanceproject;

import java.util.ArrayList;
import java.util.List;

class User {

    private String mName;
    private String mUserName;
    private String mEmail;
    private String mDescription;
    private List<String> mSkills = new ArrayList<>();

    //password to be implemented in a different class

    private int mAge;
    private int mImgId;
    private int mCredScore;
    private int mRates;

    public User(){}

    public User(String name, String userName, String email, int age){
        mName = name;
        mUserName = userName;
        mEmail = email;
        mAge = age;
    }


    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getUserName() {
        return mUserName;
    }

    public void setUserName(String userName) {
        mUserName = userName;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public List<String> getSkills() {
        return mSkills;
    }

    public void setSkills(List<String> skills) {
        mSkills = skills;
    }

    public int getAge() {
        return mAge;
    }

    public void setAge(int age) {
        mAge = age;
    }

    public int getImgId() {
        return mImgId;
    }

    public void setImgId(int imgId) {
        mImgId = imgId;
    }

    public int getCredScore() {
        return mCredScore;
    }

    public void setCredScore(int credScore) {
        mCredScore = credScore;
    }

    public int getRates() {
        return mRates;
    }

    public void setRates(int rates) {
        mRates = rates;
    }
}
