package com.example.freelanceproject;

public class Freelancer extends User{

    public Freelancer(String name, String userName, String email, int age){
        setName(name);
        setUserName(userName);
        setEmail(email);
        setAge(age);
    }

    //all basic information are implemented in User class
    //protfolio to be implemented as a generic class

}
