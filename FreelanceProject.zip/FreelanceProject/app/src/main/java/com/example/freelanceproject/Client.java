package com.example.freelanceproject;

public class Client extends User {

    public Client(String name, String userName, String email, int age){
        setName(name);
        setUserName(userName);
        setEmail(email);
        setAge(age);
    }
}
